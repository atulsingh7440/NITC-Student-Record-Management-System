<html>

<head>
    <title>NITC-Student Management System</title>
    <link rel="stylesheet" type="text/css" href="style.css">
    <style>
  <?php include "style.css" ?>
</style>
</head>

<body   >

   <div class="container">
    <h3  align="right" style="margin-right:30px;"><a  class="abc" href="login.php">Admin Login</a></h3>
    <h1 align="center">Welcome to NITC-Student Management System</h1>

   </div><br><br>
         
       <form method="post" action="home.php">   
           <table style="width:30%;" align="center" border="1">
               <tr>
                  <td colspan="2" align="center"> Student Information </td>
               </tr>

               <tr>
                  <td align="left">Enter Roll No. </td>
               <td><input type="text" name="RollNo" </td>

               </tr>

                <tr>
                <td colspan="2" align="center"><input type="submit" name="submit" value="show Details"></td>
               </tr>    
            <table>
        </form>
        <br><br>
</body>

</html>

<?php

if(isset($_POST['submit']))
{
    $rollno = $_POST['RollNo'];

    include('db_connection.php');
    include('show_function.php');
    showdetails($rollno);
}



?>
