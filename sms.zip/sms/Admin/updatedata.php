<?php

include('../db_connection.php');
    $rollno = $_POST['rollno'];
    $name   = $_POST['name'];
    $fname  = $_POST['fname'];
    $dob    = $_POST['dof'];
    $doa    = $_POST['doa'];
    $dept   = $_POST['dept'];
    $mobile = $_POST['mobile'];
    $address= $_POST['address'];
    $eid    = $_POST['eid'];
    $sid     = $_POST['sid'];
    $imagename = $_FILES['simg']['name'];
    $tempname  = $_FILES['simg']['tmp_name'];

    move_uploaded_file($tempname,"../data_images/$imagename");



    
    $qry="UPDATE `student` SET `roll_number`='$rollno',`name`='$name',`father_name`='$fname',`date_of_birth`='$dob',`date_of_admission`='$doa',`department`='$dept',`mobile_number`='$mobile',`address`='$address',`email_id`='$eid',`image`='$imagename',`id`='$sid';";
    $run =mysqli_query($con,$qry);
    
     if($run)
     {
    
        ?>
        <script>
            alert('successfully Updated !!');
            window.open('edit.php?sid=<?php echo $id;?>','_self');
            </script>
        <?php 
        } 
        else{
            echo "successfully Updated !";
        }  
    
    


?>