<?php
session_start();

   if(isset($_SESSION['uid']))
   {
       echo "";
   }
   else
   {
      header('location: ../login.php');
   }


?>

<?php
   include('header.php');
   include('titlehead.php');
?>

<table align="center">
<form action="delete_stu.php" method="post">
    <tr>
        <th>Enter Roll No.</th>
        <td><input type="text" name="rollno" placeholder="Enter Roll No." required="required"/></td>
        <td colspan="1"><input type="submit" name="submit" value="Search"/> </td>
    </tr>
    
</form>
</table>

<table align="center" width="80%"border="1" style="margin-top:10px;">
    <tr style="background-color:#000; color:#fff;">
        <th>Image</th>
        <th>Roll No.</th>
        <th>Name</th>
        <th>Dept</th>
        <th>Mob No.</th>
        <th>Edit</th>
    </tr>
    <?php
  
   if(isset($_POST['submit']))
   {
      include('../db_connection.php');
      $rollno = $_POST['rollno'];

      $sql="SELECT * FROM `student` WHERE `roll_number`='$rollno'";
      $run =mysqli_query($con,$sql);

      if(mysqli_num_rows($run)<1)
      {
          echo "<tr ><td colspan='6'>No Records Found</td></td>";
      }
      else
      {
         while($data=mysqli_fetch_assoc($run)) 
          {
              ?>
               <tr>
                   <td><img src="../data_images/<?php echo $data['image']; ?>" style="max-width:100px;"/></td>
                   <td><?php echo $data['roll_number']; ?></td>
                   <td><?php echo $data['name']; ?></td>
                   <td><?php echo $data['department']; ?></td>
                   <td><?php echo $data['mobile_number']; ?></td>
                   <td><a href="edit_delete.php?sid=<?php  echo $data['id'];?>">DELETE</a> </td>
                </tr>
                 
              <?php
          }

      }
   }
  

?>
</table>


