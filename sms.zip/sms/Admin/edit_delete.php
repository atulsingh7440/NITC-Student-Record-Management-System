<?php

include('../db_connection.php');
  
    $id=$_REQUEST['sid'];

    $qry="DELETE FROM `student` WHERE `id`='$id';";
    $run =mysqli_query($con,$qry);
    // echo $run;
    
    if($run == true)
    {
        ?>
        <script>
            alert('successfully Deleted !!');
            window.open('delete_stu.php','_self');
            </script>
        <?php    
    }
?>