<div class="admintitle" align="center">
       <h1>Welcome to Admin Dashboard</h1>
       <h2><a href="admindash.php"style="float:left; margin-left:30px; color:#fff">Back TO Dashboard</a></h2>
       <h2><a href="logout.php"style="float:right; margin-right:30px; color:#fff">Logout</a></h2>
   </div>