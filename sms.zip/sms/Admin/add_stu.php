<?php
session_start();

   if(isset($_SESSION['uid']))
   {
       echo "";
   }
   else
   {
      header('location: ../login.php');
   }


?>

<?php
   include('header.php');
   include('titlehead.php');
?>

<form method="post" action="add_stu.php" enctype="multipart/form-data">
   <table align="center" border="1" style="width:50%; margin-top:40px;">
       <tr>
           <th>Roll Number</th>
           <td> <input type="text" name="rollno" placeholder="Enter Roll Number" required> </td>
       </tr>
       <tr>
           <th>Name</th>
           <td> <input type="text" name="name" placeholder="Enter Full Name" required> </td>
       </tr>
       <tr>
           <th>Father's Name</th>
           <td> <input type="text" name="fname" placeholder="Ente father name" required> </td>
       </tr>
       <tr>
           <th>Date Of Birth</th>
           <td> <input type="date" name="dof" placeholder="Enter DOB" required> </td>
       </tr>
       <tr>
           <th>Date of Admission</th>
           <td> <input type="date" name="doa" placeholder="Enter DOA " required> </td>
       </tr>
       <tr>
           <th>Department</th>
           <td> <input type="text" name="dept" placeholder="Enter department" required> </td>
       </tr>
       <tr>
           <th>Contact Number</th>
           <td> <input type="text" name="mobile" placeholder="Enter contact number" required> </td>
       </tr>
       <tr>
           <th>Address</th>
           <td> <input type="text" name="address" placeholder="Enter Address" required> </td>
       </tr>
       <tr>
           <th>Email-Id</th>
           <td> <input type="email" name="eid" placeholder="Enter email_id" required> </td>
       </tr>
       <tr>
           <th>PHOTO</th>
           <td> <input type="file" name="simg" required> </td>
       </tr>
       <tr>
                <td colspan="2" align="center"><input type="submit" name="submit" value="submit"></td>
             </tr>

   </table>
</from>
</body>
</html>


<?php

    
if(isset($_POST['submit']))
{
    include('../db_connection.php');
    $rollno = $_POST['rollno'];
    $name   = $_POST['name'];
    $fname  = $_POST['fname'];
    $dob    = $_POST['dof'];
    $doa    = $_POST['doa'];
    $dept   = $_POST['dept'];
    $mobile = $_POST['mobile'];
    $address= $_POST['address'];
    $eid    = $_POST['eid'];
    $imagename = $_FILES['simg']['name'];
     $tempname  = $_FILES['simg']['tmp_name'];

    move_uploaded_file($tempname,"../data_images/$imagename");


    
    $qry="INSERT INTO `student`(`roll_number`, `name`, `father_name`, `date_of_birth`, `date_of_admission`, `department`, `mobile_number`, `address`, `email_id`,`image`) VALUES ('$rollno','$name','$fname','$dob','$doa','$dept','$mobile','$address','$eid','$imagename')";
    $run =mysqli_query($con,$qry);
    if($run == true)
    {
        ?>
        <script>
            alert('successfully inserted');
            </script>
        <?php    
    }
}

?>

