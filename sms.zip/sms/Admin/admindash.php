<?php
session_start();

   if(isset($_SESSION['uid']))
   {
       echo "";
   }
   else
   {
      header('location: ../login.php');
   }


?>

<?php
   include('header.php');
?>
   <div class="abc">
   <div class="admintitle" align="center">
       <h1>Welcome to Admin Dashboard</h1>
       <h2><a href="logout.php"style="float:right; margin-right:30px;">Logout</a></h2>
   </div>

    <div class="dashboard" align="center">
       <table>
             <tr>
                <td>1.</td>
                <td><a href="add_stu.php">Insert Student Details</a></td>
              </tr>  
              <tr>
                <td>2.</td>
                <td><a href="delete_stu.php">Delete Student Details</a></td>
              </tr> 
              <tr>
                <td>3.</td>
                <td><a href="update_stu.php">Update Student Details</a></td>
              </tr> 
        </table>  
        
</div>
       



</body>
</html> 