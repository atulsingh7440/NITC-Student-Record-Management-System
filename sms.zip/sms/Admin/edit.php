<?php
session_start();

   if(isset($_SESSION['uid']))
   {
       echo "";
   }
   else
   {
      header('location: ../login.php');
   }


?>

<?php
   include('header.php');
   include('titlehead.php');
   include('../db_connection.php');

   $sid = $_GET['sid'];

   $sql="SELECT * FROM `student` WHERE `id`='$sid'";
   $run =mysqli_query($con,$sql);
   $data=mysqli_fetch_assoc($run);
?>

<form method="post" action="updatedata.php" enctype="multipart/form-data">
   <table align="center" border="1" style="width:50%; margin-top:40px;">
       <tr>
           <th>Roll Number</th>
           <td> <input type="text" name="rollno" value=<?php echo $data['roll_number']; ?> required> </td>
       </tr>
       <tr>
           <th>Name</th>
           <td> <input type="text" name="name" value=<?php echo $data['name']; ?>required> </td>
       </tr>
       <tr>
           <th>Father's Name</th>
           <td> <input type="text" name="fname" value=<?php echo $data['father_name']; ?> required> </td>
       </tr>
       <tr>
           <th>Date Of Birth</th>
           <td> <input type="date" name="dof" value=<?php echo $data['date_of_birth']; ?> required> </td>
       </tr>
       <tr>
           <th>Date of Admission</th>
           <td> <input type="date" name="doa" value=<?php echo $data['date_of_admission']; ?> required> </td>
       </tr>
       <tr>
           <th>Department</th>
           <td> <input type="text" name="dept" value=<?php echo $data['department']; ?> required> </td>
       </tr>
       <tr>
           <th>Contact Number</th>
           <td> <input type="text" name="mobile" value=<?php echo $data['mobile_number']; ?> required> </td>
       </tr>
       <tr>
           <th>Address</th>
           <td> <input type="text" name="address" value=<?php echo $data['address']; ?> required> </td>
       </tr>
       <tr>
           <th>Email-Id</th>
           <td> <input type="email" name="eid" value=<?php echo $data['email_id']; ?> required> </td>
       </tr>
       <tr>
           <th>PHOTO</th>
           <td> <input type="file" name="simg" required> </td>
       </tr>
       <tr>
             <td colspan="2" align="center">
             <input type="hidden" name="sid" value="<?php echo $data['id'];  ?>"/>
             <input type="submit" name="submit" value="submit"></td>
             </tr>

   </table>
</from>