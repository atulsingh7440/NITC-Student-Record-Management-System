<!-- here we use php's library named as mysqli to connect with database
so we use the funcion of my mysqli library named as MYSQLI_CONNECT -->
<!-- and we store in a verible "$con"
"localhost/nitc_sms/db_connection.php" -->
<?php

     $con = mysqli_connect('localhost','root','','nitc_sms');

     if($con == false)
     {
         echo "Connection failed";
     }
     
?>