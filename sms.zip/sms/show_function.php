<?php

 function showdetails($rollno)
 {
      include('db_connection.php');

       $sql ="SELECT * FROM `student` WHERE `roll_number`='$rollno'";
 $run =mysqli_query($con,$sql);

 if( mysqli_num_rows($run) >0 )
 {
     $data=mysqli_fetch_assoc($run);
     ?>
        <table border="1" style="width:80%; margin-top:0px;" align="center">
              <tr>
                  <th colspan="3">Show Details</th>
              </tr>
              <tr>
                  <th rowspan="9"> <img src="data_images/<?php echo $data['image']; ?>" style="max-height:150px; max-width:120px; padding-left:20px;"  /></th>
                  <th>Roll Number</th>
                  <td><?php echo $data['roll_number']; ?></td>
              </tr>
              <tr>
                  <th>Full Name</th>
                  <td><?php echo $data['name']; ?></td>
              </tr>
              <tr>
                  <th>Father Name</th>
                  <td><?php echo $data['father_name']; ?></td>
              </tr>
              <tr>
                  <th>Date of Birth</th>
                  <td><?php echo $data['date_of_birth']; ?></td>
              </tr>
              <tr>
                  <th>Date of Admission</th>
                  <td><?php echo $data['date_of_admission']; ?></td>
              </tr>
              <tr>
                  <th>Department</th>
                  <td><?php echo $data['department']; ?></td>
              </tr>
              <tr>
                  <th>Contact Number</th>
                  <td><?php echo $data['mobile_number']; ?></td>
              </tr>
              <tr>
                  <th>Address</th>
                  <td><?php echo $data['address']; ?></td>
              </tr>
              <tr>
                  <th>E-mail ID</th>
                  <td><?php echo $data['email_id']; ?></td>
              </tr>
        </table>
      <?php
 }
 else
 {
    echo "<script>alert('No Student Found');</script>";
 }
}
?>